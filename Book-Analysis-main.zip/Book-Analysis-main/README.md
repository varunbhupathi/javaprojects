Created Book-Analysis Project in APCSA, based on requirements. Implemented using Java.
